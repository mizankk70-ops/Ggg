package com.mizan

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.*
import android.nfc.NfcAdapter
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.opencv.android.OpenCVLoader
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class MainActivity : AppCompatActivity(), GLSurfaceView.Renderer, SensorEventListener {

    // --- SYSTEM CORE ---
    private lateinit var previewView: PreviewView
    private lateinit var glSurfaceView: GLSurfaceView

    // --- SURFACE VIEWS (Body Mapping) ---
    private lateinit var surfaceEyeLeft: SurfaceView
    private lateinit var surfaceEyeRight: SurfaceView
    private lateinit var surfaceBody: SurfaceView
    private lateinit var surfaceCNS: SurfaceView
    private lateinit var surfacePineal: SurfaceView
    private lateinit var surfaceEar: SurfaceView
    private lateinit var surfaceNeck: SurfaceView
    private lateinit var surfaceHand: SurfaceView
    private lateinit var surfaceEnemy: SurfaceView
    private lateinit var surfaceMy: SurfaceView

    // --- TELEMETRY UI ---
    private lateinit var tvMicDB: TextView
    private lateinit var tvNFC: TextView
    private lateinit var tvAccel: TextView
    private lateinit var tvGPS: TextView

    // --- CONTROLS ---
    private lateinit var switchMicHack: Switch
    private lateinit var switchEyeWaves: Switch
    private lateinit var switchBodyAtmospheric: Switch
    private lateinit var switchStopHold: Switch
    private lateinit var switchAttackMode: Switch
    private lateinit var switchNFCVoltage: Switch
    private lateinit var switchPrivacyMask: Switch   // ← FIXED: was missing as field

    private lateinit var seekFrequencyMask: SeekBar
    private lateinit var seekAtmosphericIntensity: SeekBar
    private lateinit var seekEdgeProtection: SeekBar

    // --- HARDWARE HANDLES ---
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var audioRecord: AudioRecord? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private lateinit var sensorManager: SensorManager
    private lateinit var locationManager: LocationManager
    private var nfcAdapter: NfcAdapter? = null

    // --- REAL-TIME DATA STREAMS ---
    private var rmsPower = 0f
    private var accelX = 0f; private var accelY = 0f; private var accelZ = 0f
    private var gravityX = 0f; private var gravityY = 0f; private var gravityZ = 9.8f
    private var rotationX = 0f; private var rotationY = 0f; private var rotationZ = 0f
    private var magneticField = 0f
    private var cameraEdgeStrength = 0f
    private var currentLat = 0.0; private var currentLon = 0.0

    // --- STATE FLAGS ---
    private var kineticEnergy = 0f
    private var isDragging = false

    // --- AUDIO CONSTS ---
    private val sampleRate = 44100
    private val bufferSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )

    // --- GL STATE ---
    private var shaderProgram = 0
    private var textureId = 0
    private var surfaceTexture: SurfaceTexture? = null
    private var quadVBO = 0

    // --- PERMISSIONS ---
    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            if (perms.values.all { it }) initSystemCore()
            else Toast.makeText(this, "PERMISSIONS REQUIRED", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!OpenCVLoader.initLocal()) {
            Log.e("Neurova", "OpenCV failed to load")
        }

        requestPermissions.launch(
            arrayOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.NFC
            )
        )
    }

    private fun initSystemCore() {
        initViews()
        initControllers()
        startLiveAudioEchoCancel()
        startCameraEdgeDetection()
        startSensorFusion()
        startGPSAnalysis()
        startGLRenderer()
        initNFC()
    }

    private fun initViews() {
        previewView    = findViewById(R.id.previewView)
        glSurfaceView  = findViewById(R.id.glSurfaceView)

        surfaceEyeLeft  = findViewById(R.id.surfaceEyeLeft)
        surfaceEyeRight = findViewById(R.id.surfaceEyeRight)
        surfaceBody     = findViewById(R.id.surfaceBody)
        surfaceCNS      = findViewById(R.id.surfaceCNS)
        surfacePineal   = findViewById(R.id.surfacePineal)
        surfaceEar      = findViewById(R.id.surfaceEar)
        surfaceNeck     = findViewById(R.id.surfaceNeck)
        surfaceHand     = findViewById(R.id.surfaceHand)
        surfaceEnemy    = findViewById(R.id.surfaceEnemy)
        surfaceMy       = findViewById(R.id.surfaceMy)

        tvMicDB  = findViewById(R.id.tvMicDB)
        tvNFC    = findViewById(R.id.tvNFC)
        tvAccel  = findViewById(R.id.tvAccel)
        tvGPS    = findViewById(R.id.tvGPS)

        switchMicHack         = findViewById(R.id.switchMicHack)
        switchEyeWaves        = findViewById(R.id.switchEyeWaves)
        switchBodyAtmospheric = findViewById(R.id.switchBodyAtmospheric)
        switchStopHold        = findViewById(R.id.switchStopHold)
        switchAttackMode      = findViewById(R.id.switchAttackMode)
        switchNFCVoltage      = findViewById(R.id.switchNFCVoltage)
        switchPrivacyMask     = findViewById(R.id.switchPrivacyMask)  // ← FIXED

        seekFrequencyMask      = findViewById(R.id.seekFrequencyMask)
        seekAtmosphericIntensity = findViewById(R.id.seekAtmosphericIntensity)
        seekEdgeProtection     = findViewById(R.id.seekEdgeProtection)

        glSurfaceView.setZOrderMediaOverlay(false)
        previewView.setZOrderMediaOverlay(false)

        listOf(
            surfaceEyeLeft, surfaceEyeRight, surfaceBody, surfaceCNS,
            surfacePineal, surfaceEar, surfaceNeck, surfaceHand, surfaceEnemy, surfaceMy
        ).forEach { view ->
            view.setZOrderOnTop(true)
            view.holder.setFormat(PixelFormat.TRANSLUCENT)
            makeDraggable(view)
        }
    }

    private fun initControllers() {
        switchMicHack.setOnCheckedChangeListener { _, on ->
            if (on) audioRecord?.startRecording() else audioRecord?.stop()
        }
        // switchStopHold state is read in updateSurfaceViewPhysics / makeDraggable
    }

    // --- 1. LIVE AUDIO & ECHO CANCELLATION ---
    private fun startLiveAudioEchoCancel() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2
        )

        if (AcousticEchoCanceler.isAvailable()) {
            echoCanceler = AcousticEchoCanceler.create(audioRecord!!.audioSessionId)
            echoCanceler?.enabled = true
        }

        CoroutineScope(Dispatchers.IO).launch {
            val buffer = ShortArray(bufferSize / 2)
            while (isActive) {
                if (audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        rmsPower = calculateRMS(buffer)
                        withContext(Dispatchers.Main) {
                            tvMicDB.text = "AUDIO: ${"%.2f".format(rmsPower * 100)} %"
                            glSurfaceView.requestRender()
                        }
                    }
                }
                delay(10)
            }
        }
    }

    private fun calculateRMS(buffer: ShortArray): Float {
        var sum = 0.0
        for (s in buffer) sum += s.toDouble() * s.toDouble()
        return sqrt(sum / buffer.size).toFloat() / 32768f
    }

    // --- 2. SENSOR FUSION ---
    private fun startSensorFusion() {
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val delay = SensorManager.SENSOR_DELAY_GAME
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let  { sensorManager.registerListener(this, it, delay) }
        sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)?.let         { sensorManager.registerListener(this, it, delay) }
        sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let       { sensorManager.registerListener(this, it, delay) }
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { sensorManager.registerListener(this, it, delay) }
        sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)?.let  { sensorManager.registerListener(this, it, delay) }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                accelX = event.values[0]; accelY = event.values[1]; accelZ = event.values[2]
                kineticEnergy = sqrt(accelX * accelX + accelY * accelY + accelZ * accelZ)
            }
            Sensor.TYPE_GRAVITY -> {
                gravityX = event.values[0]; gravityY = event.values[1]; gravityZ = event.values[2]
            }
            Sensor.TYPE_GYROSCOPE -> {
                rotationX = event.values[0]; rotationY = event.values[1]; rotationZ = event.values[2]
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
                magneticField = sqrt(x * x + y * y + z * z)
            }
        }
        tvAccel.text = "KINETIC: ${"%.2f".format(kineticEnergy)} | GRAV-Z: ${"%.2f".format(gravityZ)}"
        updateSurfaceViewPhysics()
    }

    private fun updateSurfaceViewPhysics() {
        if (switchStopHold.isChecked) return
        val driftMult = if (switchBodyAtmospheric.isChecked) 2.0f else 0.5f
        val list = listOf(surfaceEyeLeft, surfaceEyeRight, surfaceBody, surfaceCNS,
            surfacePineal, surfaceEar, surfaceNeck, surfaceHand)
        list.forEach { surface ->
            if (!isDragging) {
                surface.translationX = (accelX * driftMult * 2f) + (rotationY * 10f)
                surface.translationY = (accelY * driftMult * 2f) + (rotationX * 10f)
                surface.alpha = (0.7f + rmsPower * 0.3f).coerceIn(0f, 1f)
            }
        }
        if (switchEyeWaves.isChecked) {
            surfaceEyeLeft.rotation  = rotationX * 5f
            surfaceEyeRight.rotation = rotationX * 5f
        }
    }

    // --- 3. CAMERA EDGE DETECTION (OpenCV) ---
    private fun startCameraEdgeDetection() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { proxy ->
                        analyzeFrame(proxy)
                        proxy.close()
                    }
                }
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analyzer
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image ?: return
        val mat = imageToMat(mediaImage)
        if (mat.empty()) { mat.release(); return }

        val gray  = Mat()
        val edges = Mat()
        Imgproc.cvtColor(mat, gray, Imgproc.COLOR_BGR2GRAY)

        val thr = seekEdgeProtection.progress * 2.0
        Imgproc.Canny(gray, edges, thr * 0.5, thr)

        val mean = MatOfDouble()
        val std  = MatOfDouble()
        Core.meanStdDev(edges, mean, std)
        cameraEdgeStrength = (mean.get(0, 0)[0] / 255.0).toFloat().coerceIn(0f, 1f)

        mean.release(); std.release(); gray.release(); edges.release(); mat.release()
    }

    private fun imageToMat(image: android.media.Image): Mat {
        val plane  = image.planes[0]
        val buffer = plane.buffer
        val bytes  = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val yuvMat = Mat(image.height + image.height / 2, image.width, CvType.CV_8UC1)
        yuvMat.put(0, 0, bytes)
        val bgr = Mat()
        Imgproc.cvtColor(yuvMat, bgr, Imgproc.COLOR_YUV2BGR_NV21)
        yuvMat.release()
        return bgr
    }

    // --- 4. GPS ---
    private val gpsListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            currentLat = loc.latitude; currentLon = loc.longitude
            tvGPS.text = "GPS: ${"%.5f".format(currentLat)}, ${"%.5f".format(currentLon)}"
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(p: String?, s: Int, b: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }

    private fun startGPSAnalysis() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, gpsListener)
    }

    // --- 5. NFC ---
    private fun initNFC() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        val status = if (nfcAdapter?.isEnabled == true) "ACTIVE (RF: ${"%.1f".format(magneticField)}uT)" else "OFFLINE"
        tvNFC.text = "NFC: $status"
    }

    // --- 6. GL RENDERER ---
    private fun startGLRenderer() {
        glSurfaceView.setEGLContextClientVersion(3)
        glSurfaceView.setRenderer(this)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0f, 0f, 0f, 0f)

        // Camera Texture
        val textures = IntArray(1)
        GLES30.glGenTextures(1, textures, 0)
        textureId = textures[0]
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        surfaceTexture = SurfaceTexture(textureId)

        // Full-Screen Quad: pos(x,y,z) + uv(u,v) = stride 5 floats = 20 bytes
        val vertices = floatArrayOf(
            -1f, -1f, 0f,  0f, 1f,
             1f, -1f, 0f,  1f, 1f,
            -1f,  1f, 0f,  0f, 0f,
             1f,  1f, 0f,  1f, 0f
        )
        val vb = ByteBuffer.allocateDirect(vertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        vb.put(vertices).position(0)

        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        quadVBO = vbo[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVBO)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertices.size * 4, vb, GLES30.GL_STATIC_DRAW)

        // Load shaders from res/raw
        val vsSource = resources.openRawResource(R.raw.vertex_shader).bufferedReader().use { it.readText() }
        val fsSource = resources.openRawResource(R.raw.fragment_shader).bufferedReader().use { it.readText() }

        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vsSource)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fsSource)
        shaderProgram = linkProgram(vs, fs)
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES30.glViewport(0, 0, w, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        surfaceTexture?.updateTexImage()

        GLES30.glUseProgram(shaderProgram)

        val posLoc = GLES30.glGetAttribLocation(shaderProgram, "aPosition")
        val texLoc = GLES30.glGetAttribLocation(shaderProgram, "aTexCoord")
        GLES30.glEnableVertexAttribArray(posLoc)
        GLES30.glEnableVertexAttribArray(texLoc)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadVBO)
        // stride = 20 bytes (5 floats), pos offset = 0, uv offset = 12 (3 floats * 4 bytes)
        GLES30.glVertexAttribPointer(posLoc, 3, GLES30.GL_FLOAT, false, 20, 0)
        GLES30.glVertexAttribPointer(texLoc, 2, GLES30.GL_FLOAT, false, 20, 12)

        fun uniform1f(name: String, value: Float) =
            GLES30.glUniform1f(GLES30.glGetUniformLocation(shaderProgram, name), value)
        fun uniform1i(name: String, value: Int) =
            GLES30.glUniform1i(GLES30.glGetUniformLocation(shaderProgram, name), value)

        // Real telemetry uniforms
        uniform1f("uTime",                System.nanoTime() / 1_000_000_000f)
        uniform1f("uMicPower",            rmsPower)
        uniform1f("uKinetic",             kineticEnergy)
        uniform1f("uGravity",             gravityZ)
        uniform1f("uCameraEdge",          cameraEdgeStrength)
        uniform1f("uRFInterference",      magneticField / 100f)   // normalise µT → ~0..1
        uniform1f("uDistortionLevel",     seekFrequencyMask.progress / 100f)
        uniform1f("uAtmosphericIntensity",seekAtmosphericIntensity.progress / 100f)
        uniform1i("uPrivacyMask",         if (switchPrivacyMask.isChecked) 1 else 0)
        uniform1i("uAttackMode",          if (switchAttackMode.isChecked) 1 else 0)

        // Bind camera texture unit 0
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        uniform1i("uTexture", 0)

        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glDisableVertexAttribArray(posLoc)
        GLES30.glDisableVertexAttribArray(texLoc)
    }

    // --- SHADER HELPERS (FIXED) ---
    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, src)
        GLES30.glCompileShader(shader)

        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)  // ← FIXED: index 0
        if (status[0] == GLES30.GL_FALSE) {
            val log = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            throw RuntimeException("Shader compile error: $log")
        }
        return shader
    }

    private fun linkProgram(vs: Int, fs: Int): Int {
        val program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)

        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        if (status[0] == GLES30.GL_FALSE) {
            val log = GLES30.glGetProgramInfoLog(program)
            GLES30.glDeleteProgram(program)
            throw RuntimeException("Program link error: $log")
        }
        return program
    }

    // --- DRAGGABLE SURFACE VIEWS ---
    private fun makeDraggable(view: SurfaceView) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = true
                    v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(100).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!switchStopHold.isChecked) {
                        v.x = event.rawX - v.width / 2f
                        v.y = event.rawY - v.height / 2f
                    }
                }
                MotionEvent.ACTION_UP -> {
                    isDragging = false
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }
            }
            true
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        super.onDestroy()
        audioRecord?.stop()
        audioRecord?.release()
        echoCanceler?.release()
        sensorManager.unregisterListener(this)
        cameraExecutor.shutdown()
        if (::locationManager.isInitialized) locationManager.removeUpdates(gpsListener)
    }
}
