#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision mediump float;

// --- SAMPLERS ---
uniform samplerExternalOES uTexture;

// --- REAL TELEMETRY UNIFORMS ---
uniform float uTime;              // seconds since boot
uniform float uMicPower;          // 0..1  RMS audio power
uniform float uKinetic;           // m/s²  accelerometer magnitude
uniform float uGravity;           // m/s²  gravity Z component
uniform float uCameraEdge;        // 0..1  OpenCV Canny density
uniform float uRFInterference;    // 0..1  normalised magnetometer

// --- USER CONTROLS ---
uniform float uDistortionLevel;       // seekFrequencyMask  0..1
uniform float uAtmosphericIntensity;  // seekAtmosphericIntensity 0..1
uniform int   uPrivacyMask;           // 0 or 1  (NightVision)
uniform int   uAttackMode;            // 0 or 1  (Glitch)

in  vec2 vTexCoord;
out vec4 FragColor;

// ─── EFFECT FUNCTIONS ─────────────────────────────────────────────────────────

// 1. NightVision Green
vec3 nightVision(vec3 col) {
    float luma = dot(col, vec3(0.299, 0.587, 0.114));
    return vec3(luma * 0.08, luma * 1.5, luma * 0.08);
}

// 2. RGB Chromatic Aberration driven by cameraEdge
vec3 rgbSplit(vec2 uv) {
    float shift = uCameraEdge * 0.018;
    float r = texture(uTexture, uv + vec2( shift, 0.0)).r;
    float g = texture(uTexture, uv).g;
    float b = texture(uTexture, uv + vec2(-shift, 0.0)).b;
    return vec3(r, g, b);
}

// 3. VHS Scanline Warp
vec2 vhsWarp(vec2 uv) {
    float scanline = sin(uv.y * 600.0 + uTime * 8.0) * 0.0015;
    float drift    = sin(uTime * 0.4) * 0.004 * uDistortionLevel;
    return uv + vec2(scanline + drift, 0.0);
}

// 4. Digital Glitch Blocks (AttackMode)
vec4 glitchBlock(vec2 uv) {
    float blockRow = floor(uv.y * 24.0);
    float rnd      = fract(sin(blockRow + uTime * 3.0) * 43758.5453);
    if (rnd < uDistortionLevel * 0.45) {
        float shift = (rnd - 0.5) * 0.12;
        return texture(uTexture, vec2(uv.x + shift, uv.y));
    }
    return texture(uTexture, uv);
}

// 5. Audio Pulse Vignette
float audioPulse(vec2 uv) {
    float d = length(uv - 0.5) * 2.0;
    return 1.0 - smoothstep(0.4, 1.0, d) * uMicPower * 1.8;
}

// 6. Kinetic Bloom (motion sensor driven)
vec3 kineticBloom(vec3 col) {
    float bloom = smoothstep(8.0, 20.0, uKinetic);  // triggers above ~8 m/s²
    return col + vec3(0.0, 0.6, 1.0) * bloom * 0.4;
}

// 7. RF Interference Static (magnetometer)
vec3 rfStatic(vec2 uv) {
    float noise = fract(sin(dot(uv * 300.0, vec2(12.9898, 78.233)) + uTime) * 43758.5453);
    return vec3(noise) * uRFInterference * 0.25;
}

// 8. Gravity Tilt Barrel Distortion
vec2 gravityDistort(vec2 uv) {
    // gravityZ ≈ 9.8 at rest; tilting reduces it
    float tilt = clamp((9.8 - uGravity) / 9.8, 0.0, 1.0);
    vec2  c    = uv - 0.5;
    float r2   = dot(c, c);
    return uv + c * r2 * tilt * 0.3;
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
void main() {
    vec2 uv = vTexCoord;

    // Gravity barrel warp
    uv = gravityDistort(uv);

    // VHS warp
    vec2 warpedUV = vhsWarp(uv);

    // Base colour sample
    vec4 baseColor;
    if (uAttackMode == 1) {
        baseColor = glitchBlock(warpedUV);
    } else {
        baseColor = texture(uTexture, warpedUV);
    }

    // RGB split (driven by OpenCV edge density)
    vec3 splitColor = rgbSplit(warpedUV);

    // Audio pulse vignette
    float pulse = audioPulse(uv);
    baseColor.rgb *= pulse;

    // Kinetic bloom
    baseColor.rgb = kineticBloom(baseColor.rgb);

    // RF static overlay
    baseColor.rgb += rfStatic(uv);

    // Blend RGB split with atmospheric intensity
    baseColor.rgb = mix(baseColor.rgb, splitColor, uAtmosphericIntensity);

    // NightVision override (privacy mask)
    if (uPrivacyMask == 1) {
        baseColor.rgb = nightVision(baseColor.rgb);
    }

    FragColor = vec4(clamp(baseColor.rgb, 0.0, 2.0), 1.0);
}
